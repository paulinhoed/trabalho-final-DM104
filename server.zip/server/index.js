var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var mysql = require('mysql');
var app = express();
var cors = require('cors');

app.use(bodyParser.json());
app.use(cors());


var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'petoo286',
    database: "homebrew"
});
connection.connect(function (err) {
    if (err) throw err;
    else console.log("Connected!");
});

app.listen(8089, function () {
    console.log("Listening port 8089!");
});


/**
 * Get all
 */
app.get('/list', function (req, res) {
    connection.query("SELECT * FROM recipes", function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Get by id
 */
app.get('/list/:id', function (req, res) {
    var id = req.params.id;
    connection.query("SELECT * FROM recipes WHERE id=" + id, function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Get by beer style
 */
app.get('/listStyle/:beerStyle', function (req, res) {
    var beerStyle = req.params.beerStyle;
    connection.query("SELECT * FROM recipes WHERE beerStyle=" + beerStyle, function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Get by abv
 */
app.get('/listAbv/:abv', function (req, res) {
    var abv = req.params.abv;
    connection.query("SELECT * FROM recipes WHERE abv=" + abv, function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Get by abv range
 */
app.post('/listAbvRange/', function (req, res) {
    var abvMin = req.body.abvMin;
    var abvMax = req.body.abvMax;
    connection.query("SELECT * FROM recipes WHERE abv BETWEEN " + abvMin + " AND " + abvMax, function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Insert
 */
app.post('/add', function (req, res) {
    var name = req.body.name
    var beerStyle = req.body.beerStyle;
    var og = req.body.og
    var fg = req.body.fg;
    var ibu = req.body.ibu;
    var abv = req.body.abv;
    var co2 = req.body.co2;
    var liter = req.body.liter;
    var firstFermentationDays = req.body.firstFermentationDays;
    var secondFermentationDays = req.body.secondFermentationDays;
    var clarificationDays = req.body.clarificationDays;
    var maturationDays = req.body.maturationDays;
    var sugarQtd = req.body.sugarQtd;
    var notes = req.body.notes;
    var sql = "INSERT INTO recipes (name,beerStyle,og,fg,ibu,abv,co2,liter,firstFermentationDays,secondFermentationDays,clarificationDays,maturationDays,sugarQtd,notes)"
        + " VALUES ('" + name + "','"
        + beerStyle + "','"
        + og + "','"
        + fg + "','"
        + ibu + "','"
        + abv + "','"
        + co2 + "','"
        + liter + "','"
        + firstFermentationDays + "','"
        + secondFermentationDays + "','"
        + clarificationDays + "','"
        + maturationDays + "','"
        + sugarQtd + "','"
        + notes + "')";
    connection.query(sql, function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Update by id
 */
app.put('/update/:id', function (req, res) {
    var id = req.params.id;
    var name = req.body.name
    var beerStyle = req.body.beerStyle;
    var og = req.body.og
    var fg = req.body.fg;
    var ibu = req.body.ibu;
    var abv = req.body.abv;
    var co2 = req.body.co2;
    var liter = req.body.liter;
    var firstFermentationDays = req.body.firstFermentationDays;
    var secondFermentationDays = req.body.secondFermentationDays;
    var clarificationDays = req.body.clarificationDays;
    var maturationDays = req.body.maturationDays;
    var sugarQtd = req.body.sugarQtd;
    var notes = req.body.notes;
    var sql = "UPDATE recipes SET name=?,beerStyle=?,og=?,fg=?,ibu=?,abv=?,co2=?,liter=?,firstFermentationDays=?,secondFermentationDays=?,clarificationDays=?,maturationDays=?,sugarQtd=?,notes=? WHERE id=?";
    connection.query(sql, [name, beerStyle, og, fg, ibu, abv, co2, liter, firstFermentationDays, secondFermentationDays, clarificationDays, maturationDays, sugarQtd, notes, id], function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Delete
 */
app.delete('/delete/:id', function (req, res) {
    var id = req.params.id;
    connection.query("DELETE FROM recipes WHERE id=" + id, function (err, result) {
        if(err) return res.status(400).json(err);
        return res.status(200).json(result);
    });
});

/**
 * Not Found
 */
function notFound(res) {
    res.status(404).send("This id doesn't exist.");
}