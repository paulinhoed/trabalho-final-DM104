var mysql = require('mysql');

var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "homebrew"
});

connection.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
    
      var sql = "CREATE TABLE recipes (id INT AUTO_INCREMENT PRIMARY KEY,"+
        "name VARCHAR(255),"+
        "beerStyle VARCHAR(255),"+
        "og VARCHAR(255),"+
        "fg VARCHAR(255),"+
        "ibu VARCHAR(255),"+
        "abv VARCHAR(255),"+
        "co2 VARCHAR(255),"+
        "liter FLOAT(3),"+
        "firstFermentationDays VARCHAR(255),"+
        "secondFermentationDays VARCHAR(255),"+
        "clarificationDays VARCHAR(255),"+
        "maturationDays VARCHAR(255),"+
        "sugarQtd VARCHAR(255),"+
        "notes VARCHAR(255))";
        connection.query(sql, function (err, result) {
            if (err) throw err;
            console.log("Table created");
        });
});